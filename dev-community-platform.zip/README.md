# DevConnect - Developer Community Platform

A frontend foundation for a Developer Community Platform built with **Next.js 16**, **TypeScript**, **App Router**, and **Tailwind CSS**.

## Features

- App Router project structure
- Shared Navbar and Footer layout
- Route group: `app/(main)`
- Static pages: `/`, `/about`, `/communities`, `/topics`, `/developers`
- Nested routes:
  - `/communities/web-development`
  - `/communities/mobile-development`
  - `/communities/ui-ux`
  - `/developers/top-rated`
  - `/developers/new-members`
- Dynamic routes:
  - `/communities/[slug]`
  - `/developers/[username]`
  - `/developers/[username]/posts/[postId]`
- Server Component rendering static data
- Client Components with interactivity:
  - Active Navbar styling
  - Join Community button
- Local static data files for communities, developers, and posts
- Bonus: not-found page, loading UI, reusable Card component, Tailwind styling

## How to Run

```bash
npm install
npm run dev
```

Open `http://localhost:3000` in your browser.

## GitHub Submission Steps

```bash
git init
git add .
git commit -m "Initial developer community platform"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_LINK
git push -u origin main
```
