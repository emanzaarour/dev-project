export default function Loading() {
  return <p className="text-center text-slate-600">Loading DevConnect...</p>;
}
