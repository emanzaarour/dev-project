import Card from './Card';
import { developers } from '../data/developers';

export default function DevelopersList() {
  return (
    <div className="grid gap-5 md:grid-cols-3">
      {developers.map((developer) => (
        <Card
          key={developer.username}
          title={developer.name}
          description={`${developer.role} • Rating ${developer.rating}/5`}
          href={`/developers/${developer.username}`}
        />
      ))}
    </div>
  );
}
