import Card from './Card';
import { communities } from '../data/communities';

// Server Component: renders static community data on the server by default.
export default function CommunitiesList() {
  return (
    <div className="grid gap-5 md:grid-cols-3">
      {communities.map((community) => (
        <Card
          key={community.slug}
          title={community.name}
          description={`${community.description} Members: ${community.members}`}
          href={`/communities/${community.slug}`}
        />
      ))}
    </div>
  );
}
