export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white py-6 text-center text-sm text-slate-500">
      © 2026 DevConnect. Built with Next.js App Router.
    </footer>
  );
}
