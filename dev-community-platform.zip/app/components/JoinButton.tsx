'use client';

import { useState } from 'react';

export default function JoinButton() {
  const [joined, setJoined] = useState(false);

  return (
    <button
      onClick={() => setJoined((current) => !current)}
      className="rounded-xl bg-indigo-700 px-5 py-3 font-semibold text-white shadow-sm hover:bg-indigo-800"
    >
      {joined ? 'Joined ✓' : 'Join Community'}
    </button>
  );
}
