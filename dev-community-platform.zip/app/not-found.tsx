import Link from 'next/link';

export default function NotFound() {
  return (
    <section className="rounded-2xl bg-white p-8 text-center shadow-sm">
      <h1 className="text-3xl font-bold">Page Not Found</h1>
      <p className="mt-3 text-slate-600">The page you are looking for does not exist.</p>
      <Link href="/" className="mt-6 inline-block rounded-xl bg-indigo-700 px-5 py-3 font-semibold text-white">
        Back Home
      </Link>
    </section>
  );
}
