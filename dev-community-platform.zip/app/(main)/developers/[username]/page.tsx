import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getDeveloperByUsername } from '@/app/data/developers';
import { getPostsByDeveloper } from '@/app/data/posts';

export default async function DeveloperProfilePage({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  const developer = getDeveloperByUsername(username);

  if (!developer) notFound();

  const developerPosts = getPostsByDeveloper(username);

  return (
    <section className="space-y-6">
      <div className="rounded-2xl bg-white p-8 shadow-sm">
        <p className="text-sm font-semibold uppercase tracking-wide text-indigo-700">Developer Profile</p>
        <h1 className="mt-3 text-3xl font-bold">{developer.name}</h1>
        <p className="mt-1 font-medium text-slate-700">@{developer.username}</p>
        <p className="mt-4 text-lg font-semibold">{developer.role}</p>
        <p className="mt-2 max-w-2xl leading-7 text-slate-600">{developer.bio}</p>
      </div>

      <div>
        <h2 className="mb-3 text-2xl font-bold">Posts</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {developerPosts.map((post) => (
            <Link key={post.id} href={`/developers/${username}/posts/${post.id}`} className="rounded-xl bg-white p-5 shadow-sm hover:shadow-md">
              <h3 className="font-semibold">{post.title}</h3>
              <p className="mt-2 text-sm text-slate-600">{post.excerpt}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
