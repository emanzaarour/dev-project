import { notFound } from 'next/navigation';
import { getDeveloperByUsername } from '@/app/data/developers';
import { getPost } from '@/app/data/posts';

export default async function DeveloperPostPage({ params }: { params: Promise<{ username: string; postId: string }> }) {
  const { username, postId } = await params;
  const developer = getDeveloperByUsername(username);
  const post = getPost(username, postId);

  if (!developer || !post) notFound();

  return (
    <article className="rounded-2xl bg-white p-8 shadow-sm">
      <p className="text-sm font-semibold uppercase tracking-wide text-indigo-700">Developer Post</p>
      <h1 className="mt-3 text-3xl font-bold">{post.title}</h1>
      <p className="mt-2 text-slate-600">By {developer.name} • @{developer.username}</p>
      <p className="mt-6 max-w-3xl leading-7 text-slate-700">{post.excerpt}</p>
    </article>
  );
}
