import { developers } from '@/app/data/developers';

export default function TopRatedDevelopersPage() {
  const topRated = [...developers].sort((a, b) => b.rating - a.rating);

  return (
    <section className="space-y-5">
      <h1 className="text-3xl font-bold">Top Rated Developers</h1>
      <p className="text-slate-600">This nested route displays developers sorted by rating.</p>
      <div className="space-y-3">
        {topRated.map((developer) => (
          <div key={developer.username} className="rounded-xl bg-white p-5 shadow-sm">
            <h2 className="font-semibold">{developer.name}</h2>
            <p className="text-sm text-slate-600">{developer.role} • {developer.rating}/5</p>
          </div>
        ))}
      </div>
    </section>
  );
}
