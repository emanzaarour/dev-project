import DevelopersList from '@/app/components/DevelopersList';

export default function DevelopersPage() {
  return (
    <section className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Developers</h1>
        <p className="mt-2 text-slate-600">Meet developers from different technical backgrounds and view their profiles.</p>
      </div>
      <DevelopersList />
    </section>
  );
}
