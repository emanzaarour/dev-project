import { developers } from '@/app/data/developers';

export default function NewMembersPage() {
  const newest = [...developers].sort((a, b) => Number(b.joined) - Number(a.joined));

  return (
    <section className="space-y-5">
      <h1 className="text-3xl font-bold">New Members</h1>
      <p className="text-slate-600">This nested route displays the newest developers who joined the platform.</p>
      <div className="space-y-3">
        {newest.map((developer) => (
          <div key={developer.username} className="rounded-xl bg-white p-5 shadow-sm">
            <h2 className="font-semibold">{developer.name}</h2>
            <p className="text-sm text-slate-600">Joined in {developer.joined}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
