export default function AboutPage() {
  return (
    <section className="space-y-4">
      <h1 className="text-3xl font-bold">About DevConnect</h1>
      <p className="max-w-3xl leading-7 text-slate-600">
        DevConnect is a student-built community platform concept created with Next.js 16. It demonstrates App Router routing, nested routes, dynamic routes, route groups, reusable components, and a mix of server and client components.
      </p>
    </section>
  );
}
