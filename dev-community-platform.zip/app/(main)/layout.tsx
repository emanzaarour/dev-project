export default function MainRouteGroupLayout({ children }: { children: React.ReactNode }) {
  return <section>{children}</section>;
}
