import Link from 'next/link';

export default function HomePage() {
  return (
    <section className="rounded-3xl bg-white p-8 shadow-sm md:p-12">
      <p className="text-sm font-semibold uppercase tracking-wide text-indigo-700">Developer Community Platform</p>
      <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-950 md:text-5xl">Connect, learn, and grow with developers.</h1>
      <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600">
        DevConnect is a simple frontend platform where developers can browse communities, explore topics, and view developer profiles.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link href="/communities" className="rounded-xl bg-indigo-700 px-5 py-3 font-semibold text-white hover:bg-indigo-800">Explore Communities</Link>
        <Link href="/developers" className="rounded-xl border border-slate-300 px-5 py-3 font-semibold text-slate-700 hover:bg-slate-100">View Developers</Link>
      </div>
    </section>
  );
}
