const topics = ['Next.js', 'React', 'TypeScript', 'UI/UX', 'APIs', 'Career Growth'];

export default function TopicsPage() {
  return (
    <section className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Topics</h1>
        <p className="mt-2 text-slate-600">Explore popular topics discussed by developers in the platform.</p>
      </div>
      <div className="flex flex-wrap gap-3">
        {topics.map((topic) => (
          <span key={topic} className="rounded-full bg-white px-5 py-3 font-medium text-slate-700 shadow-sm">
            {topic}
          </span>
        ))}
      </div>
    </section>
  );
}
