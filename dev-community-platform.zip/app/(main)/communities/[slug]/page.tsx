import { notFound } from 'next/navigation';
import JoinButton from '@/app/components/JoinButton';
import { getCommunityBySlug } from '@/app/data/communities';

export default async function CommunityDetailsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const community = getCommunityBySlug(slug);

  if (!community) notFound();

  return (
    <section className="rounded-2xl bg-white p-8 shadow-sm">
      <p className="text-sm font-semibold uppercase tracking-wide text-indigo-700">Community Details</p>
      <h1 className="mt-3 text-3xl font-bold">{community.name}</h1>
      <p className="mt-3 max-w-2xl leading-7 text-slate-600">{community.description}</p>
      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <div className="rounded-xl bg-slate-50 p-4">
          <p className="text-sm text-slate-500">Focus</p>
          <p className="font-semibold">{community.focus}</p>
        </div>
        <div className="rounded-xl bg-slate-50 p-4">
          <p className="text-sm text-slate-500">Members</p>
          <p className="font-semibold">{community.members}</p>
        </div>
      </div>
      <div className="mt-6">
        <JoinButton />
      </div>
    </section>
  );
}
