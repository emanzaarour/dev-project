import CommunitiesList from '@/app/components/CommunitiesList';

export default function CommunitiesPage() {
  return (
    <section className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Communities</h1>
        <p className="mt-2 text-slate-600">Browse developer communities and choose the one that matches your interests.</p>
      </div>
      <CommunitiesList />
    </section>
  );
}
