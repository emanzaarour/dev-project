export default function uiuxPage() {
  return (
    <section className="rounded-2xl bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-bold">Ui Ux Community</h1>
      <p className="mt-3 text-slate-600">This nested route focuses on Ui Ux resources, discussions, and community learning.</p>
    </section>
  );
}
