export default function webdevelopmentPage() {
  return (
    <section className="rounded-2xl bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-bold">Web Development Community</h1>
      <p className="mt-3 text-slate-600">This nested route focuses on Web Development resources, discussions, and community learning.</p>
    </section>
  );
}
