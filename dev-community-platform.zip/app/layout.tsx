import type { Metadata } from 'next';
import './globals.css';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

export const metadata: Metadata = {
  title: 'DevConnect Community Platform',
  description: 'A developer community frontend built with Next.js 16 App Router.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900">
        <Navbar />
        <main className="mx-auto min-h-[75vh] max-w-6xl px-5 py-10">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
