export type Developer = {
  username: string;
  name: string;
  role: string;
  bio: string;
  rating: number;
  joined: string;
};

export const developers: Developer[] = [
  {
    username: 'maya-code',
    name: 'Maya Haddad',
    role: 'Frontend Developer',
    bio: 'Passionate about building accessible interfaces with React and Next.js.',
    rating: 4.9,
    joined: '2024',
  },
  {
    username: 'omar-backend',
    name: 'Omar Khalil',
    role: 'Backend Developer',
    bio: 'Works with APIs, databases, and clean backend architecture.',
    rating: 4.8,
    joined: '2023',
  },
  {
    username: 'sara-designs',
    name: 'Sara Mansour',
    role: 'UI/UX Designer',
    bio: 'Creates user-friendly products through research, testing, and visual design.',
    rating: 4.7,
    joined: '2025',
  },
];

export function getDeveloperByUsername(username: string) {
  return developers.find((developer) => developer.username === username);
}
