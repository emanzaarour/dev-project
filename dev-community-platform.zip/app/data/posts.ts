export type Post = {
  id: string;
  username: string;
  title: string;
  excerpt: string;
};

export const posts: Post[] = [
  {
    id: '1',
    username: 'maya-code',
    title: 'How I structure a Next.js project',
    excerpt: 'A simple approach to keeping routes, components, and data organized.',
  },
  {
    id: '2',
    username: 'maya-code',
    title: 'Why accessibility matters in frontend work',
    excerpt: 'Small UI choices can make web apps easier for everyone to use.',
  },
  {
    id: '1',
    username: 'omar-backend',
    title: 'API tips for beginners',
    excerpt: 'Start with clean endpoints, clear responses, and useful error messages.',
  },
  {
    id: '1',
    username: 'sara-designs',
    title: 'Design systems for small teams',
    excerpt: 'Reusable design rules help developers and designers move faster.',
  },
];

export function getPost(username: string, postId: string) {
  return posts.find((post) => post.username === username && post.id === postId);
}

export function getPostsByDeveloper(username: string) {
  return posts.filter((post) => post.username === username);
}
