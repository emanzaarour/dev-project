export type Community = {
  slug: string;
  name: string;
  description: string;
  members: number;
  focus: string;
};

export const communities: Community[] = [
  {
    slug: 'web-development',
    name: 'Web Development',
    description: 'A space for frontend, backend, full-stack, and modern web framework discussions.',
    members: 1280,
    focus: 'Next.js, React, APIs, UI performance',
  },
  {
    slug: 'mobile-development',
    name: 'Mobile Development',
    description: 'Developers building Android, iOS, Flutter, and React Native applications.',
    members: 860,
    focus: 'Flutter, React Native, Android, iOS',
  },
  {
    slug: 'ui-ux',
    name: 'UI/UX Design',
    description: 'A creative community for interface design, user experience, and design systems.',
    members: 720,
    focus: 'Wireframes, usability, design systems',
  },
];

export function getCommunityBySlug(slug: string) {
  return communities.find((community) => community.slug === slug);
}
